<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://agency.risesmm.in' );
define('STYLESHEETS_URL', '//agency.risesmm.in' );
date_default_timezone_set('Asia/Kolkata');

/* 
 ini_set("display_errors","1");
error_reporting(E_ERROR);  */  

error_reporting(0);
return [
  'db' => [
    'name'    =>  'crestsmm_crest' ,
    'host'    =>  'localhost',
    'user'    =>  'crestsmm_crest' ,
    'pass'    =>  'crestsmm_crest' ,
    'charset' =>  'utf8mb4'
  ]
];

?>
<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}

// Function to destroy any previous session data
function destroy_previous_session($userId) {
    // Destroy all session variables and session data
    session_unset();
    session_destroy();
    // Clear user-related cookies if they exist
    setcookie("u_id", "", time() - 3600, '/');
    setcookie("u_password", "", time() - 3600, '/');
    setcookie("u_login", "", time() - 3600, '/');
    setcookie("currency_hash", "", time() - 3600, '/');
}

if( !route(1) ){
    $route[1] = "login";
}

if( route(1) == "login" ){
    $title .= $pagetitle;
}elseif( route(1) == "register" ){
    $title .= $languageArray["signup.title"];
}

if( ( route(1) == "login" || route(1) == "register") && $_SESSION["msmbilisim_userlogin"] ){
     header("Location:".site_url());exit();
}
if(route(1) == "neworder" || route(1) == "orders" || route(1) == "tickets" || route(1) == "addfunds" || route(1) == "account" || route(1) == "dripfeeds" || route(1) == "reference" || route(1) == "subscriptions" ) {
    header("Location:".site_url()); exit();
}

// Google Login configuration (omitted for brevity)

if( $route[1] == "login" && $_POST ){

    $username = strip_tags($_POST["username"]);
    $username = filter_var($username, FILTER_SANITIZE_STRING);
    $pass = $_POST["password"];
    $remember = $_POST["remember"];

    // Check if a user session already exists for this user
    if (isset($_SESSION["msmbilisim_userid"])) {
        destroy_previous_session($_SESSION["msmbilisim_userid"]);
    }

    // Authentication logic for logging in with username or email (assuming $username, $pass)
    $row = $conn->prepare("SELECT * FROM clients WHERE (username=:username OR email=:username) && password=:password");
    $row->execute(array("username" => $username, "password" => md5($pass)));
    $row = $row->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        // Set new session data after invalidating any existing sessions
        $_SESSION["msmbilisim_userlogin"] = 1;
        $_SESSION["msmbilisim_userid"] = $row["client_id"];
        $_SESSION["msmbilisim_userpass"] = md5($pass);
        $_SESSION["currency_hash"] = get_currency_hash_by_code(get_default_currency());

        // Setting cookies for session persistence
        if ($remember) {
            setcookie("u_id", $row["client_id"], strtotime('+28 days'), '/', null, null, true);
            setcookie("u_password", $row["password"], strtotime('+28 days'), '/', null, null, true);
            setcookie("u_login", 'ok', strtotime('+28 days'), '/', null, null, true);
            setcookie("currency_hash", $_SESSION["currency_hash"], strtotime('+28 days'), '/', null, null, true);
        } else {
            setcookie("u_id", $row["client_id"], strtotime('+7 days'), '/', null, null, true);
            setcookie("u_password", $row["password"], strtotime('+7 days'), '/', null, null, true);
            setcookie("u_login", 'ok', strtotime('+7 days'), '/', null, null, true);
            setcookie("currency_hash", $_SESSION["currency_hash"], strtotime('+7 days'), '/', null, null, true);
        }

        // Redirect to homepage or dashboard after successful login
        header('Location:'.site_url(''));
        exit();
    } else {
        $error = 1;
        $errorText = $languageArray["error.signin.notmatch"];
    }
}

// Google OAuth login and other sections (omitted for brevity)
?>

<?php include 'new-header.php'; ?>
<div class="container margin-top-container">
<div class="row">
<div class="col-md-6 col-12 category-list-div">

<ul id="category-list" class="list-group col">
<?=$list?>
</ul>


</div>
</div>
</div>
<?php include "new-footer.php";?>
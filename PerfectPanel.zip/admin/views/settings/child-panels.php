<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body">
      <form action="" method="post">
        <div class="form-group">
          <label for="" class="control-label">Price</label>
          <input type="text" class="form-control" name="childpanel_price" value="<?=$settings["childpanel_price"]?>">
        </div>
        <button type="submit" class="btn btn-primary">Update Settings</button>
      </form>
    </div>
  </div>
</div>
